export class Pagination {

  public pages: any;
  public browser: any;
  public current: any;
  public total: any;
  public count: any;
  public page: any;
  public perPage: any;

  constructor(
  ) { }
}
