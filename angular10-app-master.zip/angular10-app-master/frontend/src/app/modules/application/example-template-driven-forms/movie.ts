export class Movie {
  name: string;
  releaseDate: string;
  domestic: string;
  international: string;
  worldwide: string;
}
