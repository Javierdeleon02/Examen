export const ITEMS: any[] =
  [
    {
      name: 'prototype',
      link: 'prototype'
    },
    {
      name: 'form-control',
      link: 'form-control'
    },
    {
      name: 'form-control-class',
      link: 'form-control-class'
    },
    {
      name: 'form-group',
      link: 'form-group'
    },
    {
      name: 'form-builder',
      link: 'form-builder'
    },
    {
      name: 'form-builder-nested',
      link: 'form-builder-nested'
    },
    {
      name: 'form-array',
      link: 'form-array'
    },
    {
      name: 'form-multi',
      link: 'form-multi'
    }
  ];
