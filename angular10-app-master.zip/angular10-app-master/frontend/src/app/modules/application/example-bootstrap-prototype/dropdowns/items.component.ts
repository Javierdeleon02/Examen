import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dropdowns',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class DropdownsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
