import { Component } from '@angular/core';

@Component({
  selector: 'app-example-bootstrap-prototype',
  templateUrl: './example-bootstrap-prototype.component.html',
  styleUrls: ['./example-bootstrap-prototype.component.css']
})

export class ExampleBootstrapPrototypeComponent {
}
