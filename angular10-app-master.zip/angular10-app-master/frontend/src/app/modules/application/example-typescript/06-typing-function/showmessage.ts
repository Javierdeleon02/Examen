export function showmessage(message: string): string {
  return message + ' Add log';
}

/* function showmessage(message) {
  return message + ' Add log';
} */
