export class Movie {
  name: string;
  event: string;

  constructor() {
    const essai = 'essai';
  }

  changeName(): void {
    this.name = this.name + ':changeName';
  }

  addEvent(): void {
    //    event = '32321';
  }
}
