export const variableExport10 = 10;
const variable20 = 20;

export {
  variableExport10 as variable10,
  variable20
};
