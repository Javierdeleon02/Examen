export class Smartphone {
  name: string;
  model: string;
  prize: string;
  year: string;
}
