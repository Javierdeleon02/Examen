export class Movie {
  name: string;
  releaseDate: string;

  constructor() {
  }

}