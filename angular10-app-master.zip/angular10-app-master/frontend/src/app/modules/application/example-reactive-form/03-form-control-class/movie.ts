export class Movie {
  name: string;
  releaseDate: string;
  franchise: boolean;
  budget: number;
  worldwide: number;
  summary: string;
}
