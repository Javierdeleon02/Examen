DROP TABLE users;
DROP SEQUENCE users_id_seq;

DROP TABLE continent;
DROP SEQUENCE continent_id_seq;

DROP TABLE country;
DROP SEQUENCE country_id_seq;

DROP TABLE city;
DROP SEQUENCE city_id_seq;

DROP TABLE gender;
DROP SEQUENCE gender_id_seq;

DROP TABLE profession;
DROP SEQUENCE profession_id_seq;

DROP TABLE genre;
DROP SEQUENCE genre_id_seq;

DROP TABLE movie;
DROP SEQUENCE movie_id_seq;

DROP TABLE images;
DROP SEQUENCE image_id_seq;

DROP TABLE person;
DROP SEQUENCE person_id_seq;

DROP TABLE views;
DROP SEQUENCE views_id_seq;

DROP TABLE trailer;
DROP SEQUENCE trailer_id_seq;

DROP TABLE movie_person;

DROP TABLE movie_genre;

DROP TABLE movie_image;

