import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spinners',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class SpinnersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
